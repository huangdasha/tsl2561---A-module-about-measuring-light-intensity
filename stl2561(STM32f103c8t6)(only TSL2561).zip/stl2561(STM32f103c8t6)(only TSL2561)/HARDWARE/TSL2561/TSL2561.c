#include "TSL2561.h"
#include "delay.h"
#include "myiic.h"
#include <stdio.h>
#include <math.h>
#include "sys.h"

void TSL2561_Write(u8 command,u8 date)
{
	IIC_Start();
	IIC_Send_Byte(TSL2561_ADDR<<1);
	IIC_Wait_Ack();
	IIC_Send_Byte(command);
	IIC_Wait_Ack();
	IIC_Send_Byte(date);
	IIC_Wait_Ack();
	IIC_Stop();
}


u16 TSL2561_Read(u8 command)
{
	u16 date;
	IIC_Start();
	IIC_Send_Byte(TSL2561_ADDR<<1);
	IIC_Wait_Ack();
	IIC_Send_Byte(command);
	IIC_Wait_Ack();
	
	IIC_Start();
	IIC_Send_Byte((TSL2561_ADDR<<1)+1);
	IIC_Wait_Ack();
	date=IIC_Read_Byte(1);
	date+=(IIC_Read_Byte(1)<<8);
	IIC_Stop();
	return date;
}

void TSL2561_PowerOn(void)
{
	TSL2561_Write(TSL2561_CMD,TSL2561_POWER_ON);
}


void TSL2561_PowerDown(void)
{
	TSL2561_Write(TSL2561_CMD,TSL2561_POWER_DOWN);
}


void TSL2561_TimingSet(u8 TIME)
{
	IIC_Start();
	IIC_Send_Byte(TSL2561_ADDR<<1);
	IIC_Wait_Ack();
	IIC_Send_Byte(TSL2561_TIMING);
	IIC_Wait_Ack();
	IIC_Send_Byte(TIME);
	IIC_Wait_Ack();
	IIC_Stop();
}

void TSL2561_Init(u8 Time_model)
{
	TSL2561_PowerOn();
	
	TSL2561_TimingSet(Time_model);
}


u16 TSL2561_Chanel0Read(void)
{
    u16 buff;
	buff=TSL2561_Read(TSL2561_DATA0_LOW);
	return buff;
}


u16 TSL2561_Chanel1Read(void)
{
    u16 buff;
	buff=TSL2561_Read(TSL2561_DATA1_LOW);
	return buff;
}
float TSL2561_calculate_lus(uint16_t channel0_value  , uint16_t channel1_value)
{
	float temp_value = (float)channel1_value/(float)channel0_value;
	float lux_value = 0;
	// ��������ּ��㷽�����ݴ������Ĳ�ͬ��װ����ѡ�񣬾��忴�����ֲᡣ������������Ƕ���CS Packages��װ�ļ��㷽����
	
	//CS Packages��
	if(temp_value <= 0.52 && temp_value > 0)
	{
		lux_value = 0.0315 * channel0_value - 0.0593 * channel0_value * pow((channel1_value/channel0_value) , 1.4);
	}
	else if(temp_value <= 0.65 && temp_value > 0.52)
	{
		lux_value = 0.0229 * channel0_value - 0.0291 * channel1_value;
	}
	else if(temp_value <= 0.80 && temp_value > 0.65)
	{
		lux_value = 0.0157 * channel0_value - 0.0180 * channel1_value;
	}
	else if(temp_value <= 1.3 && temp_value > 0.8)
	{
		lux_value = 0.00338 * channel0_value - 0.00260 * channel1_value;
	}
	else lux_value = 0;
	
//	// T , FN , CL Packages:
//	if(temp_value <= 0.5 && temp_value > 0)
//	{
//		lux_value = 0.0304 * channel0_value - 0.062 * channel0_value * pow((channel1_value/channel0_value) , 1.4);
//	}
//	else if(temp_value <= 0.61 && temp_value > 0.5)
//	{
//		lux_value = 0.0224 * channel0_value - 0.031 * channel1_value;
//	}
//	else if(temp_value <= 0.80 && temp_value > 0.61)
//	{
//		lux_value = 0.0128 * channel0_value - 0.0153 * channel1_value;
//	}
//	else if(temp_value <= 1.3 && temp_value > 0.8)
//	{
//		lux_value = 0.00146 * channel0_value - 0.00112 * channel1_value;
//	}
//	else lux_value = 0;

	return lux_value;
}
